package ru.openai.dailinet;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Random;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 41;
    private FrameLayout root;
    private ImageView backgroundImage;
    private EditText question;
    private TextView result, probabilityLabel;
    private SeekBar probability;
    private SharedPreferences prefs;
    private final Random random = new Random();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        buildScreen();
        String saved = prefs.getString("background", null);
        if (saved != null) {
            try { showBackground(Uri.parse(saved)); } catch (Exception ignored) {}
        }
        probability.setProgress(prefs.getInt("yesChance", 50));
        updateProbabilityLabel();
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }

    private TextView label(String text, float size) {
        TextView v = new TextView(this); v.setText(text); v.setTextSize(size); v.setTextColor(Color.WHITE); return v;
    }

    private void buildScreen() {
        root = new FrameLayout(this);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(46,35,91), Color.rgb(22,24,52), Color.rgb(15,17,35)}));
        backgroundImage = new ImageView(this); backgroundImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(backgroundImage, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(this); shade.setBackgroundColor(0x990B0B1B);
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL); content.setPadding(dp(24), dp(26), dp(24), dp(24));
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, -1); cp.gravity = Gravity.CENTER;
        root.addView(content, cp);

        TextView title = label("Да или Нет?", 32); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER); content.addView(title, new LinearLayout.LayoutParams(-1, dp(54)));
        TextView subtitle = label("Задай вопрос — получи ответ", 15); subtitle.setTextColor(0xFFDAD7F2);
        subtitle.setGravity(Gravity.CENTER); content.addView(subtitle);
        addSpace(content, 34);

        question = new EditText(this); question.setSingleLine(false); question.setMinLines(1); question.setMaxLines(3);
        question.setTextColor(Color.WHITE); question.setHintTextColor(0xFFDDD9F0); question.setHint("Напиши свой вопрос...");
        question.setTextSize(17); question.setPadding(dp(16), dp(14), dp(16), dp(14));
        question.setBackground(rounded(0x88302D4E, 16));
        content.addView(question, new LinearLayout.LayoutParams(-1, dp(58)));
        addSpace(content, 22);

        Button answer = new Button(this); answer.setText("УЗНАТЬ ОТВЕТ"); answer.setTextSize(16);
        answer.setTextColor(Color.WHITE); answer.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        answer.setAllCaps(false); answer.setBackground(rounded(0xFF7967E8, 18));
        answer.setElevation(dp(8));
        content.addView(answer, new LinearLayout.LayoutParams(-1, dp(62)));
        answer.setOnClickListener(v -> drawAnswer());

        result = label("ТВОЙ ОТВЕТ", 30); result.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        result.setGravity(Gravity.CENTER); result.setAlpha(0f);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(74)); rp.topMargin = dp(18);
        content.addView(result, rp);

        addSpace(content, 18);
        probabilityLabel = label("Шанс «ДА»: 50%", 16); probabilityLabel.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        content.addView(probabilityLabel);
        probability = new SeekBar(this); probability.setMax(100); probability.setProgress(50);
        content.addView(probability, new LinearLayout.LayoutParams(-1, dp(42)));
        probability.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int value, boolean fromUser) { updateProbabilityLabel(); }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) { prefs.edit().putInt("yesChance", b.getProgress()).apply(); }
        });
        TextView range = label("0% — НЕТ                         100% — ДА", 12); range.setTextColor(0xFFDAD7F2);
        content.addView(range);

        addSpace(content, 28);
        Button choose = new Button(this); choose.setText("Выбрать фото на фон"); choose.setAllCaps(false);
        choose.setTextColor(Color.WHITE); choose.setBackground(rounded(0x665B5680, 16));
        content.addView(choose, new LinearLayout.LayoutParams(-1, dp(52)));
        choose.setOnClickListener(v -> pickBackground());

        TextView note = label("Ответ выбирается случайно по заданной вероятности", 11);
        note.setTextColor(0xFFC9C5DE); note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2); np.topMargin = dp(18);
        content.addView(note, np);
        setContentView(root);
    }

    private void addSpace(LinearLayout layout, int height) {
        View space = new View(this); layout.addView(space, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private void updateProbabilityLabel() { probabilityLabel.setText("Шанс «ДА»: " + probability.getProgress() + "%"); }

    private void drawAnswer() {
        int yesChance = probability.getProgress();
        boolean yes = random.nextInt(100) < yesChance;
        result.setText(yes ? "ДА" : "НЕТ");
        result.setTextColor(yes ? 0xFFB8FFCF : 0xFFFFC0C8);
        result.setScaleX(0.7f); result.setScaleY(0.7f); result.setAlpha(0f);
        result.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(280)
                .setInterpolator(new DecelerateInterpolator()).start();
    }

    private void pickBackground() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_IMAGE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                prefs.edit().putString("background", uri.toString()).apply(); showBackground(uri);
            } catch (Exception e) { Toast.makeText(this, "Не удалось открыть это фото", Toast.LENGTH_SHORT).show(); }
        }
    }

    private void showBackground(Uri uri) {
        backgroundImage.setImageURI(uri);
        backgroundImage.setVisibility(View.VISIBLE);
    }
}
